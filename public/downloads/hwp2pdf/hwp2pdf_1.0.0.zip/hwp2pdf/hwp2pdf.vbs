Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
pyw = sh.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python312\pythonw.exe")
If Not fso.FileExists(pyw) Then pyw = "pythonw"
sh.Run """" & pyw & """ """ & dir & "\app.py""", 0, False
