"""HWP/HWPX → PDF 변환기."""

from __future__ import annotations

import os
import random
import re
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk

import mascot
import memory
from converter import (
    ConvertOptions,
    Quality,
    collect_files,
    default_output_path,
    hangul_installed,
    unique_path,
)


APP_TITLE = "hwp2pdf"
FONT = "맑은 고딕"
SUPPORTED_GLOBS = [("한글 문서", "*.hwp *.hwpx"), ("모든 파일", "*.*")]
PAGE_RE = re.compile(r"\s*\d+\s*(-\s*\d+\s*)?(,\s*\d+\s*(-\s*\d+\s*)?)*\s*")

C = {
    "bg": "#FAF5EF",
    "card": "#FFFDFA",
    "border": "#ECE1D4",
    "ink": "#2B231E",
    "text": "#4D423B",
    "subtle": "#8C7E73",
    "brand": "#1F7A6D",
    "brand_h": "#18645A",
    "warm_tint": "#FFF3E8",
    "warm_line": "#F2D3BC",
    "warm_text": "#A8513A",
    "row": "#FAF4ED",
    "row_h": "#F3EAE0",
    "hwp": "#3D7BE0",
    "hwpx": "#8A63D8",
    "ok": "#1E8E5A",
    "err": "#C8453A",
    "err_tint": "#FCEAE5",
    "seg_bg": "#F2EBE3",
    "seg_hover": "#E9DFD4",
    "track": "#EDE3D7",
    "check": "#C9BBAE",
    "stop": "#7A6C62",
    "stop_h": "#655850",
}

QUALITY = {
    "원본": (Quality.VERY_HIGH, "이미지를 원본 그대로 유지합니다 · 가장 선명"),
    "높음": (Quality.HIGH, "인쇄·보관에 충분한 화질 · 용량 약간 감소"),
    "보통": (Quality.MEDIUM, "화면으로 보기 좋은 화질 · 용량 절반 수준"),
    "가볍게": (Quality.LOW, "메일·메신저 전송용 · 가장 작은 용량"),
}


def f(size: int, bold: bool = False) -> ctk.CTkFont:
    return ctk.CTkFont(family=FONT, size=size, weight="bold" if bold else "normal")


def shorten(text: str, limit: int) -> str:
    return text if len(text) <= limit else text[: limit - 1] + "…"


def open_in_explorer(path: Path) -> None:
    if path.is_file():
        subprocess.run(["explorer", "/select,", str(path)], check=False)
    elif path.is_dir():
        os.startfile(path)  # type: ignore[attr-defined]


def hide_console() -> None:
    if sys.platform != "win32":
        return
    try:
        import ctypes

        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 0)
    except Exception:
        pass


class FileRow(ctk.CTkFrame):
    def __init__(self, master, path: Path, on_remove):
        super().__init__(master, fg_color=C["row"], corner_radius=10, height=40)
        self.path = path
        self.output: Path | None = None
        self.pack_propagate(False)

        ext = path.suffix[1:].upper()
        ctk.CTkLabel(
            self,
            text=ext,
            width=44,
            height=20,
            corner_radius=10,
            fg_color=C["hwpx"] if ext == "HWPX" else C["hwp"],
            text_color="#FFFFFF",
            font=f(9, True),
        ).pack(side="left", padx=(10, 10))

        self.name = ctk.CTkLabel(
            self,
            text=shorten(path.stem, 38),
            font=f(12),
            text_color=C["ink"],
            anchor="w",
        )
        self.name.pack(side="left", fill="x", expand=True)

        self.remove_btn = ctk.CTkButton(
            self,
            text="✕",
            width=26,
            height=26,
            corner_radius=6,
            fg_color="transparent",
            hover_color=C["err_tint"],
            text_color=C["subtle"],
            font=f(11),
            command=lambda: on_remove(self),
        )
        self.remove_btn.pack(side="right", padx=(0, 6))

        self.state = ctk.CTkLabel(
            self, text="", width=104, anchor="e", font=f(11), text_color=C["subtle"]
        )
        self.state.pack(side="right", padx=(0, 6))

        for w in (self, self.name, self.state):
            w.bind("<Double-Button-1>", self._reveal)

    def set_state(self, text: str, color: str | None = None) -> None:
        self.state.configure(text=text, text_color=color or C["subtle"])

    def _reveal(self, _e=None) -> None:
        open_in_explorer(self.output if self.output and self.output.exists() else self.path)


class App(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        ctk.set_appearance_mode("light")

        self.title("hwp2pdf")
        self.geometry("560x700")
        self.minsize(500, 640)
        self.configure(fg_color=C["bg"])

        self.rows: list[FileRow] = []
        self.custom_dir: Path | None = None
        self.open_when_done = ctk.BooleanVar(value=True)
        self._busy = False
        self._cancel = threading.Event()
        self._mood = "idle"
        self._mood_until = 0.0
        self._frame = 0
        self._images: dict[tuple[str, int], ctk.CTkImage] = {}
        self.memory = memory.load()

        self._build()
        self._restore_settings()
        self._enable_drop()
        self._refresh()
        self._set_window_icon()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(100, self._check_env)
        self.after(400, self._animate)

    # ── mascot ──────────────────────────────────────────────
    def _img(self, mood: str, size: int) -> ctk.CTkImage:
        key = (mood, size)
        if key not in self._images:
            pil = mascot.draw(mood, size * 2)
            self._images[key] = ctk.CTkImage(light_image=pil, size=(size, size))
        return self._images[key]

    def _show(self, mood: str) -> None:
        self.head_mascot.configure(image=self._img(mood, 44))
        self.empty_mascot.configure(image=self._img(mood, 76))

    def set_mood(self, mood: str, hold: float = 0.0) -> None:
        self._mood = mood
        self._mood_until = time.monotonic() + hold if hold else 0.0
        self._show(mood)

    def _animate(self) -> None:
        self._frame += 1
        if self._busy:
            self._show("work_up" if self._frame % 2 else "work")
        else:
            if self._mood_until and time.monotonic() > self._mood_until:
                self.set_mood("idle")
            if self._mood == "idle":
                if random.random() < 0.09:
                    self._show("blink")
                    self.after(140, lambda: self._mood == "idle" and self._show("idle"))
        self.after(380, self._animate)

    def _set_window_icon(self) -> None:
        try:
            ico = Path(tempfile.gettempdir()) / "hwp2pdf_icon.ico"
            mascot.save_icon(str(ico))
            # CustomTkinter applies its own icon ~200 ms after start; set ours afterwards.
            self.after(300, lambda: self.iconbitmap(str(ico)))
        except Exception:
            pass

    # ── remembered settings ─────────────────────────────────
    def _restore_settings(self) -> None:
        m = self.memory
        if m.get("quality") in QUALITY:
            self.quality_seg.set(m["quality"])
            self._on_quality(m["quality"])
        self.open_when_done.set(bool(m.get("open_when_done", True)))
        saved_dir = m.get("custom_dir")
        if saved_dir and Path(saved_dir).is_dir():
            self.custom_dir = Path(saved_dir)
            self.out_path.configure(text=f"{shorten(saved_dir, 48)}   변경")
            if m.get("out_mode") == "다른 폴더":
                self.out_seg.set("다른 폴더")
                self._on_out_mode("다른 폴더")

    def _save_settings(self) -> None:
        self.memory.update(
            quality=self.quality_seg.get(),
            out_mode=self.out_seg.get(),
            custom_dir=str(self.custom_dir) if self.custom_dir else None,
            open_when_done=self.open_when_done.get(),
        )
        memory.save(self.memory)

    def _on_close(self) -> None:
        self._cancel.set()
        self._save_settings()
        self.destroy()

    def _idle_status(self) -> None:
        n = memory.today_count(self.memory)
        if n:
            self._set_status(f"오늘 벌써 {n}개를 PDF로 만들었어요", C["subtle"])
        else:
            self._set_status("")

    # ── layout ──────────────────────────────────────────────
    def _build(self) -> None:
        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=20, pady=(14, 18))

        head = ctk.CTkFrame(body, fg_color="transparent")
        head.pack(fill="x", pady=(0, 10))
        self.head_mascot = ctk.CTkLabel(head, text="", image=self._img("idle", 44))
        self.head_mascot.pack(side="left", padx=(0, 10))
        titles = ctk.CTkFrame(head, fg_color="transparent")
        titles.pack(side="left")
        line1 = ctk.CTkFrame(titles, fg_color="transparent")
        line1.pack(anchor="w")
        ctk.CTkLabel(line1, text="hwp2pdf", font=f(19, True), text_color=C["ink"]).pack(
            side="left"
        )
        ctk.CTkLabel(
            line1, text="  한글 문서를 PDF로 뿅!", font=f(11), text_color=C["subtle"]
        ).pack(side="left", pady=(4, 0))
        self.greeting = ctk.CTkLabel(
            titles, text=memory.greeting(), font=f(11), text_color=C["warm_text"], height=16
        )
        self.greeting.pack(anchor="w")
        self.env_label = ctk.CTkLabel(head, text="", font=f(11), text_color=C["subtle"])
        self.env_label.pack(side="right", anchor="n", pady=(6, 0))

        # Bottom-up packing keeps the convert button visible; the file list absorbs shrinkage.
        self._build_footer(body)
        self._build_settings(body)
        self._build_files(body)

    def _card(self, parent) -> ctk.CTkFrame:
        return ctk.CTkFrame(
            parent,
            fg_color=C["card"],
            corner_radius=16,
            border_width=1,
            border_color=C["border"],
        )

    def _build_files(self, parent) -> None:
        card = self._card(parent)
        card.pack(side="top", fill="both", expand=True, pady=(0, 12))

        bar = ctk.CTkFrame(card, fg_color="transparent")
        bar.pack(fill="x", padx=16, pady=(14, 10))
        ctk.CTkLabel(bar, text="파일", font=f(14, True), text_color=C["ink"]).pack(
            side="left"
        )
        self.count_label = ctk.CTkLabel(bar, text="", font=f(12), text_color=C["subtle"])
        self.count_label.pack(side="left", padx=(6, 0))

        self.add_folder_btn = self._ghost(bar, "폴더 추가", self.add_folder)
        self.add_folder_btn.pack(side="right")
        self.add_btn = self._ghost(bar, "파일 추가", self.add_files)
        self.add_btn.pack(side="right", padx=(0, 6))
        self.clear_btn = ctk.CTkButton(
            bar,
            text="모두 지우기",
            width=64,
            height=26,
            corner_radius=6,
            fg_color="transparent",
            hover_color=C["err_tint"],
            text_color=C["subtle"],
            font=f(11),
            command=self.clear_files,
        )

        self.list_host = ctk.CTkFrame(card, fg_color="transparent")
        self.list_host.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        self.empty = ctk.CTkFrame(
            self.list_host,
            fg_color=C["warm_tint"],
            corner_radius=14,
            border_width=2,
            border_color=C["warm_line"],
            cursor="hand2",
        )
        self.empty_mascot = ctk.CTkLabel(self.empty, text="", image=self._img("idle", 76))
        self.empty_mascot.place(relx=0.5, rely=0.36, anchor="center")
        e1 = ctk.CTkLabel(
            self.empty,
            text="한글 파일을 여기에 쏙 넣어 주세요",
            font=f(13, True),
            text_color=C["warm_text"],
        )
        e1.place(relx=0.5, rely=0.64, anchor="center")
        e2 = ctk.CTkLabel(
            self.empty,
            text="끌어다 놓거나 클릭해서 고를 수 있어요 · HWP, HWPX, 폴더 모두 OK",
            font=f(11),
            text_color=C["text"],
        )
        e2.place(relx=0.5, rely=0.76, anchor="center")
        for w in (self.empty, self.empty_mascot, e1, e2):
            w.bind("<Button-1>", lambda _e: self.add_files())

        self.scroll = ctk.CTkScrollableFrame(
            self.list_host,
            fg_color="transparent",
            scrollbar_button_color=C["border"],
            scrollbar_button_hover_color=C["subtle"],
        )
        self.scroll._parent_canvas.bind("<Configure>", lambda _e: self._sync_scrollbar(), add="+")

    def _sync_scrollbar(self) -> None:
        canvas = self.scroll._parent_canvas
        bbox = canvas.bbox("all")
        needed = bool(bbox) and (bbox[3] - bbox[1]) > canvas.winfo_height() + 2
        if needed:
            self.scroll._scrollbar.grid()
        else:
            self.scroll._scrollbar.grid_remove()
            canvas.yview_moveto(0)

    def _build_settings(self, parent) -> None:
        card = self._card(parent)
        card.pack(side="bottom", fill="x", pady=(0, 14))
        grid = ctk.CTkFrame(card, fg_color="transparent")
        grid.pack(fill="x", padx=16, pady=14)
        grid.grid_columnconfigure(1, weight=1)

        def label(row: int, text: str) -> None:
            ctk.CTkLabel(
                grid, text=text, font=f(12, True), text_color=C["ink"], width=72, anchor="w"
            ).grid(row=row, column=0, sticky="nw", pady=(6, 0))

        # Quality
        label(0, "품질")
        qbox = ctk.CTkFrame(grid, fg_color="transparent")
        qbox.grid(row=0, column=1, sticky="ew")
        self.quality_seg = self._segmented(
            qbox, list(QUALITY), self._on_quality, initial="원본"
        )
        self.quality_seg.pack(fill="x")
        self.quality_hint = ctk.CTkLabel(
            qbox, text="", font=f(11), text_color=C["subtle"], anchor="w"
        )
        self.quality_hint.pack(fill="x", pady=(4, 0))
        self._on_quality("원본")

        self._divider(grid, 1)

        # Pages
        label(2, "페이지")
        pbox = ctk.CTkFrame(grid, fg_color="transparent")
        pbox.grid(row=2, column=1, sticky="ew")
        pbox.grid_columnconfigure(1, weight=1)
        self.page_seg = self._segmented(
            pbox, ["전체", "직접 지정"], self._on_page_mode, initial="전체", width=170
        )
        self.page_seg.grid(row=0, column=0, sticky="w")
        self.page_entry = ctk.CTkEntry(
            pbox,
            placeholder_text="예: 1-3, 5, 8-10",
            height=32,
            corner_radius=12,
            border_width=1,
            border_color=C["border"],
            fg_color=C["card"],
            text_color=C["ink"],
            placeholder_text_color=C["subtle"],
            font=f(12),
        )
        self.page_entry.bind("<KeyRelease>", lambda _e: self._validate_pages())
        self.page_hint = ctk.CTkLabel(
            pbox, text="", font=f(11), text_color=C["subtle"], anchor="w"
        )

        self._divider(grid, 3)

        # Output
        label(4, "저장 위치")
        obox = ctk.CTkFrame(grid, fg_color="transparent")
        obox.grid(row=4, column=1, sticky="ew")
        obox.grid_columnconfigure(1, weight=1)
        self.out_seg = self._segmented(
            obox, ["원본과 같은 폴더", "다른 폴더"], self._on_out_mode,
            initial="원본과 같은 폴더", width=230,
        )
        self.out_seg.grid(row=0, column=0, sticky="w")
        self.out_path = ctk.CTkButton(
            obox,
            text="",
            height=28,
            anchor="w",
            fg_color="transparent",
            hover_color=C["row_h"],
            text_color=C["brand"],
            font=f(11),
            command=self._choose_dir,
        )

    def _build_footer(self, parent) -> None:
        self.convert_btn = ctk.CTkButton(
            parent,
            text="PDF로 변환하기",
            height=46,
            corner_radius=14,
            fg_color=C["brand"],
            hover_color=C["brand_h"],
            text_color="#FFFFFF",
            text_color_disabled="#E6EEF0",
            font=f(14, True),
            command=self._on_convert_click,
        )
        self.convert_btn.pack(side="bottom", fill="x")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(side="bottom", fill="x", pady=(0, 8))
        self.status_row = row

        self.progress = ctk.CTkProgressBar(
            parent, height=6, corner_radius=3, progress_color=C["brand"], fg_color=C["track"]
        )
        self.progress.set(0)
        self.status = ctk.CTkLabel(row, text="", font=f(11), text_color=C["text"], anchor="w")
        self.status.pack(side="left", fill="x", expand=True)
        ctk.CTkCheckBox(
            row,
            text="완료 후 폴더 열기",
            variable=self.open_when_done,
            checkbox_width=16,
            checkbox_height=16,
            corner_radius=4,
            border_width=2,
            border_color=C["check"],
            fg_color=C["brand"],
            hover_color=C["brand_h"],
            text_color=C["text"],
            font=f(11),
        ).pack(side="right")

    def _segmented(self, parent, values, command, initial, width=None):
        seg = ctk.CTkSegmentedButton(
            parent,
            values=values,
            command=command,
            height=32,
            corner_radius=12,
            border_width=3,
            fg_color=C["seg_bg"],
            selected_color=C["brand"],
            selected_hover_color=C["brand_h"],
            unselected_color=C["seg_bg"],
            unselected_hover_color=C["seg_hover"],
            text_color=C["ink"],
            font=f(12, True),
            **({"width": width} if width else {}),
        )
        original_set = seg.set

        def set_and_recolor(value, *args, **kwargs):
            original_set(value, *args, **kwargs)
            self._fix_seg_colors(seg)

        seg.set = set_and_recolor
        seg.set(initial)
        return seg

    def _fix_seg_colors(self, seg) -> None:
        current = seg.get()
        for value, btn in seg._buttons_dict.items():
            btn.configure(text_color="#FFFFFF" if value == current else C["text"])

    def _divider(self, grid, row: int) -> None:
        ctk.CTkFrame(grid, fg_color=C["border"], height=1).grid(
            row=row, column=0, columnspan=2, sticky="ew", pady=12
        )

    def _ghost(self, parent, text, command) -> ctk.CTkButton:
        return ctk.CTkButton(
            parent,
            text=text,
            width=84,
            height=30,
            corner_radius=15,
            border_width=1,
            border_color=C["border"],
            fg_color=C["card"],
            hover_color=C["row_h"],
            text_color=C["ink"],
            font=f(12),
            command=command,
        )

    # ── settings handlers ───────────────────────────────────
    def _on_quality(self, value: str) -> None:
        self.quality_hint.configure(text=QUALITY[value][1])
        self._fix_seg_colors(self.quality_seg)

    def _on_page_mode(self, value: str) -> None:
        self._fix_seg_colors(self.page_seg)
        if value == "직접 지정":
            self.page_entry.grid(row=0, column=1, sticky="ew", padx=(8, 0))
            self.page_hint.grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))
            self._validate_pages()
            self.page_entry.focus_set()
        else:
            self.page_entry.grid_remove()
            self.page_hint.grid_remove()

    def _validate_pages(self) -> bool:
        spec = self.page_entry.get().strip()
        if not spec:
            self.page_hint.configure(
                text="쉼표로 구분 · 문서보다 큰 번호는 자동으로 제외됩니다",
                text_color=C["subtle"],
            )
            self.page_entry.configure(border_color=C["border"])
            return False
        if PAGE_RE.fullmatch(spec):
            self.page_hint.configure(
                text="쉼표로 구분 · 문서보다 큰 번호는 자동으로 제외됩니다",
                text_color=C["subtle"],
            )
            self.page_entry.configure(border_color=C["brand"])
            return True
        self.page_hint.configure(text="숫자, 쉼표(,), 하이픈(-)만 쓸 수 있어요", text_color=C["err"])
        self.page_entry.configure(border_color=C["err"])
        return False

    def _on_out_mode(self, value: str) -> None:
        self._fix_seg_colors(self.out_seg)
        if value == "다른 폴더":
            if self.custom_dir is None and not self._choose_dir():
                self.out_seg.set("원본과 같은 폴더")
                self._fix_seg_colors(self.out_seg)
                return
            self.out_path.grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))
        else:
            self.out_path.grid_remove()

    def _choose_dir(self) -> bool:
        initial = str(self.custom_dir or Path.home() / "Desktop")
        folder = filedialog.askdirectory(title="PDF를 저장할 폴더", initialdir=initial)
        if not folder:
            return False
        self.custom_dir = Path(folder)
        self.out_path.configure(text=f"{shorten(str(self.custom_dir), 48)}   변경")
        return True

    # ── files ───────────────────────────────────────────────
    def _enable_drop(self) -> None:
        try:
            import windnd

            def dropped(paths):
                items = [Path(p if isinstance(p, str) else p.decode("mbcs")) for p in paths]
                self.after(0, lambda: self._add(items, from_drop=True))

            windnd.hook_dropfiles(self, func=dropped, force_unicode=True)
        except Exception:
            pass

    def add_files(self) -> None:
        if self._busy:
            return
        paths = filedialog.askopenfilenames(title="HWP · HWPX 파일 선택", filetypes=SUPPORTED_GLOBS)
        if paths:
            self._add([Path(p) for p in paths])

    def add_folder(self) -> None:
        if self._busy:
            return
        folder = filedialog.askdirectory(title="폴더 선택")
        if folder:
            self._add([Path(folder)])

    def _add(self, paths: list[Path], from_drop: bool = False) -> None:
        if self._busy:
            return
        existing = {str(r.path.resolve()).lower() for r in self.rows}
        added = 0
        for p in collect_files(paths):
            key = str(p.resolve()).lower()
            if key not in existing:
                existing.add(key)
                self._append(p)
                added += 1
        self._refresh()
        if added:
            self._set_status(f"{added}개 파일이 쏙 들어왔어요")
            self.set_mood("happy", hold=1.6)
        elif from_drop:
            self._set_status("HWP · HWPX 파일만 넣을 수 있어요", C["err"])
            self.set_mood("sad", hold=2.0)
        else:
            self._set_status("이미 목록에 있는 파일이에요")

    def _append(self, path: Path) -> None:
        row = FileRow(self.scroll, path, self._remove_row)
        row.pack(fill="x", pady=(0, 6))
        self.rows.append(row)

    def _remove_row(self, row: FileRow) -> None:
        if self._busy:
            return
        row.destroy()
        self.rows.remove(row)
        self._refresh()

    def clear_files(self) -> None:
        if self._busy:
            return
        for r in self.rows:
            r.destroy()
        self.rows.clear()
        self._refresh()

    def _refresh(self) -> None:
        n = len(self.rows)
        if n:
            self.empty.pack_forget()
            self.scroll.pack(fill="both", expand=True)
            self.count_label.configure(text=f"{n}개")
            self.clear_btn.pack(side="left", padx=(8, 0), after=self.count_label)
            self.convert_btn.configure(text=f"PDF로 변환하기  ·  {n}개")
            self.after_idle(self._sync_scrollbar)
        else:
            self.scroll.pack_forget()
            self.empty.pack(fill="both", expand=True)
            self.count_label.configure(text="")
            self.clear_btn.pack_forget()
            self.convert_btn.configure(text="PDF로 변환하기")
            self._idle_status()

    # ── conversion ──────────────────────────────────────────
    def _check_env(self) -> None:
        if hangul_installed():
            self.env_label.configure(text="● 한글 연결됨", text_color=C["ok"])
        else:
            self.env_label.configure(text="● 한컴오피스 한글이 필요합니다", text_color=C["err"])

    def _on_convert_click(self) -> None:
        if self._busy:
            self._cancel.set()
            self.convert_btn.configure(state="disabled", text="지금 파일까지만 하고 멈출게요…")
            return
        self._start()

    def _start(self) -> None:
        if not self.rows:
            self.add_files()
            return
        if not hangul_installed():
            messagebox.showerror(APP_TITLE, "한컴오피스 한글이 설치되어 있어야 변환할 수 있습니다.")
            return

        page_spec = ""
        if self.page_seg.get() == "직접 지정":
            if not self._validate_pages():
                self.page_entry.focus_set()
                self._set_status("변환할 페이지를 입력해 주세요", C["err"])
                return
            page_spec = self.page_entry.get().strip()

        out_dir = self.custom_dir if self.out_seg.get() == "다른 폴더" else None
        options = ConvertOptions(
            page_range=page_spec,
            quality=QUALITY[self.quality_seg.get()][0],
            overwrite=True,
        )

        rows = list(self.rows)
        for r in rows:
            r.output = None
            r._error = None  # type: ignore[attr-defined]
            r.name.configure(text_color=C["ink"])
            r.set_state("대기")
            r.remove_btn.configure(state="disabled")

        self._busy = True
        self._cancel.clear()
        self.convert_btn.configure(
            text="중지",
            fg_color=C["stop"],
            hover_color=C["stop_h"],
        )
        self.progress.set(0)
        self.progress.pack(side="bottom", fill="x", pady=(0, 8), after=self.status_row)
        self._set_status("한글을 깨우는 중…")
        self._show("work")
        threading.Thread(
            target=self._worker, args=(rows, out_dir, options), daemon=True
        ).start()

    def _worker(self, rows: list[FileRow], out_dir: Path | None, options: ConvertOptions) -> None:
        from converter import HangulSession, convert_file

        total = len(rows)
        ok = fail = 0
        outputs: list[Path] = []
        started = time.perf_counter()
        ui = self.after

        try:
            with HangulSession(visible=False) as session:
                for i, row in enumerate(rows):
                    if self._cancel.is_set():
                        break
                    target_dir = out_dir or row.path.parent
                    target = unique_path(default_output_path(row.path, target_dir))
                    ui(0, lambda r=row: r.set_state("변환 중…", C["brand"]))

                    def prog(_msg, frac, i=i, row=row):
                        ui(0, lambda: (
                            self.progress.set((i + frac) / total),
                            self._set_status(f"{i + 1}/{total}  {shorten(row.path.name, 40)}"),
                        ))

                    res = convert_file(row.path, target, options, progress=prog, hwp=session.hwp)
                    if res.ok and res.output:
                        ok += 1
                        outputs.append(res.output)
                        row.output = res.output
                        ui(0, lambda r=row, n=res.pages_exported: r.set_state(f"완료 · {n}쪽", C["ok"]))
                    else:
                        fail += 1
                        err = res.error or "알 수 없는 오류"
                        ui(0, lambda r=row, e=err: r.set_state("실패", C["err"]))
                        ui(0, lambda r=row, e=err: r.name.configure(text_color=C["err"]))
                        row._error = err  # type: ignore[attr-defined]
        except Exception as exc:
            ui(0, lambda e=str(exc): messagebox.showerror(APP_TITLE, f"한글을 실행할 수 없습니다.\n{e}"))

        elapsed = time.perf_counter() - started
        cancelled = self._cancel.is_set()
        ui(0, lambda: self._finish(rows, ok, fail, outputs, elapsed, cancelled, out_dir))

    def _finish(self, rows, ok, fail, outputs, elapsed, cancelled, out_dir) -> None:
        self._busy = False
        self.progress.pack_forget()
        self.convert_btn.configure(state="normal", fg_color=C["brand"], hover_color=C["brand_h"])
        for r in self.rows:
            r.remove_btn.configure(state="normal")
            if r.state.cget("text") == "대기":
                r.set_state("")
        self._refresh()

        took = f"{elapsed:.1f}초"
        today = memory.add_today(self.memory, ok) if ok else memory.today_count(self.memory)
        self._save_settings()
        tally = f" · 오늘 {today}개째" if today > ok else ""

        if fail and ok:
            msg, color, mood = f"{ok}개는 잘 됐어요. {fail}개만 다시 봐 주세요", C["err"], "sad"
        elif fail:
            msg, color, mood = "이번엔 변환하지 못했어요. 아래 내용을 확인해 주세요", C["err"], "sad"
        elif cancelled:
            msg, color, mood = f"여기까지 할게요 · {ok}개 완료{tally}", C["text"], "idle"
        elif ok == 1:
            msg, color, mood = f"PDF가 완성됐어요. 수고하셨어요!  ({took}{tally})", C["ok"], "cheer"
        else:
            msg, color, mood = f"{ok}개 모두 PDF가 됐어요. 수고하셨어요!  ({took}{tally})", C["ok"], "cheer"
        self._set_status(msg, color)
        self.set_mood(mood, hold=6.0 if mood != "idle" else 0.0)

        if fail:
            errors = [
                f"· {r.path.name}\n   {getattr(r, '_error', '')}"
                for r in rows
                if getattr(r, "_error", None)
            ]
            messagebox.showwarning(
                APP_TITLE,
                "변환하지 못한 파일이 있어요.\n\n"
                + "\n".join(errors[:8])
                + "\n\n한글에서 열려 있거나 암호가 걸린 파일이면 그럴 수 있어요.\n"
                "파일을 닫고 다시 시도해 주세요.",
            )

        if outputs and self.open_when_done.get():
            open_in_explorer(outputs[0] if len(outputs) == 1 else (out_dir or outputs[0].parent))

    def _set_status(self, text: str, color: str | None = None) -> None:
        self.status.configure(text=text, text_color=color or C["text"])


def main() -> None:
    hide_console()
    App().mainloop()


if __name__ == "__main__":
    main()
