"""Tiny document mascot drawn with Pillow — no image assets needed."""

from __future__ import annotations

from functools import lru_cache

from PIL import Image, ImageDraw

INK = (52, 40, 34, 255)
LINE = (31, 122, 109, 255)
PAPER = (255, 253, 249, 255)
FOLD = (251, 226, 208, 255)
CHEEK = (255, 150, 130, 170)
SWEAT = (120, 190, 235, 255)
HEART = (255, 112, 96, 255)

MOODS = ("idle", "blink", "work", "work_up", "happy", "cheer", "sad")

_S = 8  # supersampling factor for smooth edges


def _p(*xy: float) -> list[float]:
    return [v * _S for v in xy]


@lru_cache(maxsize=64)
def draw(mood: str = "idle", size: int = 64) -> Image.Image:
    """Return an RGBA mascot image of `size`×`size` pixels."""
    base = 64
    img = Image.new("RGBA", (base * _S, base * _S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    dy = -2 if mood == "work_up" else 0

    # Page body: rounded rectangle with the top-right corner cut off and folded
    left, top, right, bottom, fold = 12, 6 + dy, 52, 58 + dy, 13
    w = 3 * _S
    d.rounded_rectangle(_p(left, top, right, bottom), radius=6 * _S, fill=PAPER, outline=LINE, width=w)
    d.polygon(_p(right - fold, top - 2, right + 2, top - 2, right + 2, top + fold), fill=(0, 0, 0, 0))
    d.polygon(_p(right - fold, top, right - fold + 2, top + fold - 2, right, top + fold), fill=FOLD)
    d.line(_p(right - fold, top, right, top + fold), fill=LINE, width=w)
    d.line(_p(right - fold, top, right - fold + 1.5, top + fold - 1.5, right, top + fold), fill=LINE, width=int(2.2 * _S), joint="curve")
    for x, y in ((right - fold, top), (right, top + fold)):
        d.ellipse(_p(x - 1.5, y - 1.5, x + 1.5, y + 1.5), fill=LINE)

    ex1, ex2, ey = 25, 39, 34 + dy

    # Cheeks
    for cx in (ex1 - 5, ex2 + 5):
        d.ellipse(_p(cx - 4, ey + 5, cx + 4, ey + 10), fill=CHEEK)

    # Eyes
    if mood == "blink":
        for x in (ex1, ex2):
            d.line(_p(x - 3, ey, x + 3, ey), fill=INK, width=int(2.4 * _S))
    elif mood in ("happy", "cheer"):
        for x in (ex1, ex2):
            d.arc(_p(x - 3.5, ey - 2, x + 3.5, ey + 4), 200, 340, fill=INK, width=int(2.4 * _S))
    else:
        r = 3.2
        for x in (ex1, ex2):
            d.ellipse(_p(x - r, ey - r, x + r, ey + r), fill=INK)
            d.ellipse(_p(x - r + 1.3, ey - r + 0.8, x - r + 2.8, ey - r + 2.3), fill=PAPER)

    if mood == "sad":
        d.line(_p(ex1 - 4, ey - 7, ex1 + 2, ey - 9), fill=INK, width=2 * _S)
        d.line(_p(ex2 + 4, ey - 7, ex2 - 2, ey - 9), fill=INK, width=2 * _S)

    # Mouth
    mx, my = 32, 43 + dy
    if mood in ("happy", "cheer"):
        d.chord(_p(mx - 5, my - 3, mx + 5, my + 5), 0, 180, fill=INK)
        d.chord(_p(mx - 2.6, my + 1.5, mx + 2.6, my + 4.6), 0, 180, fill=(255, 130, 130, 255))
    elif mood in ("work", "work_up"):
        d.ellipse(_p(mx - 2, my - 1, mx + 2, my + 3), fill=INK)
    elif mood == "sad":
        d.arc(_p(mx - 4, my, mx + 4, my + 6), 200, 340, fill=INK, width=int(2.2 * _S))
    else:
        d.arc(_p(mx - 4, my - 4, mx + 4, my + 2), 20, 160, fill=INK, width=int(2.2 * _S))

    if mood in ("work", "work_up"):
        d.ellipse(_p(47, 20 + dy, 51, 26 + dy), fill=SWEAT)
        d.polygon(_p(47.4, 22 + dy, 49, 17 + dy, 50.6, 22 + dy), fill=SWEAT)

    if mood == "cheer":
        _heart(d, 9, 9, 6.5)

    return img.resize((size, size), Image.LANCZOS)


def _heart(d: ImageDraw.ImageDraw, cx: float, cy: float, r: float) -> None:
    half = r / 2
    d.ellipse(_p(cx - r, cy - half, cx, cy + half), fill=HEART)
    d.ellipse(_p(cx, cy - half, cx + r, cy + half), fill=HEART)
    d.polygon(_p(cx - r + 0.3, cy + 0.6, cx + r - 0.3, cy + 0.6, cx, cy + r + 0.5), fill=HEART)


def save_icon(path: str) -> None:
    draw("happy", 256).save(path, sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (256, 256)])
