"""HWP/HWPX → PDF conversion engine using Hangul COM automation."""

from __future__ import annotations

import os
import re
import shutil
import tempfile
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Callable, Iterable, Optional

import pymupdf as fitz


SUPPORTED_EXTENSIONS = {".hwp", ".hwpx"}
ProgressCallback = Callable[[str, float], None]


class Quality(Enum):
    VERY_HIGH = "very_high"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

    @property
    def label(self) -> str:
        return {
            Quality.VERY_HIGH: "매우 높음",
            Quality.HIGH: "높음",
            Quality.MEDIUM: "보통",
            Quality.LOW: "낮음",
        }[self]

    @property
    def jpeg_quality(self) -> Optional[int]:
        return {
            Quality.VERY_HIGH: None,
            Quality.HIGH: 92,
            Quality.MEDIUM: 75,
            Quality.LOW: 55,
        }[self]

    @property
    def image_dpi(self) -> Optional[int]:
        return {
            Quality.VERY_HIGH: None,
            Quality.HIGH: 200,
            Quality.MEDIUM: 150,
            Quality.LOW: 96,
        }[self]


QUALITY_CHOICES = [
    (Quality.VERY_HIGH, "매우 높음 — 원본 품질 유지"),
    (Quality.HIGH, "높음 — 보관·공유용"),
    (Quality.MEDIUM, "보통 — 용량 균형"),
    (Quality.LOW, "낮음 — 전송용·작은 용량"),
]


@dataclass
class ConvertOptions:
    page_range: str = ""  # empty = all pages; e.g. "1-3,5,8-10"
    quality: Quality = Quality.VERY_HIGH
    overwrite: bool = True
    open_folder_when_done: bool = False
    visible_hangul: bool = False


@dataclass
class ConvertResult:
    source: Path
    output: Optional[Path] = None
    page_count: int = 0
    pages_exported: int = 0
    elapsed_sec: float = 0.0
    error: Optional[str] = None
    skipped: bool = False

    @property
    def ok(self) -> bool:
        return self.error is None and not self.skipped


@dataclass
class BatchSummary:
    results: list[ConvertResult] = field(default_factory=list)

    @property
    def success_count(self) -> int:
        return sum(1 for r in self.results if r.ok)

    @property
    def fail_count(self) -> int:
        return sum(1 for r in self.results if r.error)


PAGE_TOKEN_RE = re.compile(
    r"^\s*(\d+)\s*(?:-\s*(\d+)\s*)?$",
    re.UNICODE,
)


def parse_page_range(spec: str, total_pages: int) -> list[int]:
    """Parse '1-3,5,8-10' into 1-based page numbers. Empty = all pages."""
    if total_pages < 1:
        raise ValueError("문서에 페이지가 없습니다.")

    text = (spec or "").strip()
    if not text or text in {"*", "all", "전체"}:
        return list(range(1, total_pages + 1))

    pages: list[int] = []
    seen: set[int] = set()
    for raw in text.replace(" ", "").split(","):
        if not raw:
            continue
        m = PAGE_TOKEN_RE.match(raw)
        if not m:
            raise ValueError(f"잘못된 페이지 지정: '{raw}' (예: 1-3,5,8-10)")
        start = int(m.group(1))
        end = int(m.group(2)) if m.group(2) else start
        if start < 1 or end < 1:
            raise ValueError("페이지 번호는 1 이상이어야 합니다.")
        if start > end:
            start, end = end, start
        for p in range(start, min(end, total_pages) + 1):
            if p not in seen:
                seen.add(p)
                pages.append(p)

    if not pages:
        raise ValueError(f"지정한 페이지가 문서 범위(1–{total_pages}쪽)를 벗어납니다.")
    return pages


def unique_path(path: Path) -> Path:
    """Return `path`, or `name (1).pdf`, `name (2).pdf`… if it already exists."""
    if not path.exists():
        return path
    i = 1
    while True:
        candidate = path.with_name(f"{path.stem} ({i}){path.suffix}")
        if not candidate.exists():
            return candidate
        i += 1


def hangul_installed() -> bool:
    import winreg

    try:
        winreg.CloseKey(winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, r"HWPFrame.HwpObject\CLSID"))
        return True
    except OSError:
        return False


def default_output_path(source: Path, output_dir: Path) -> Path:
    return output_dir / f"{source.stem}.pdf"


def is_supported(path: Path) -> bool:
    return path.suffix.lower() in SUPPORTED_EXTENSIONS


def collect_files(paths: Iterable[Path]) -> list[Path]:
    files: list[Path] = []
    seen: set[str] = set()
    for p in paths:
        p = Path(p)
        if p.is_dir():
            for child in sorted(p.rglob("*")):
                if child.is_file() and is_supported(child):
                    key = str(child.resolve()).lower()
                    if key not in seen:
                        seen.add(key)
                        files.append(child)
        elif p.is_file() and is_supported(p):
            key = str(p.resolve()).lower()
            if key not in seen:
                seen.add(key)
                files.append(p)
    return files


def _ensure_hangul_available() -> None:
    import win32com.client  # noqa: F401

    try:
        import win32com.client as win32

        prog = win32.Dispatch("HWPFrame.HwpObject")
        try:
            prog.Quit()
        except Exception:
            pass
    except Exception as exc:
        raise RuntimeError(
            "한글(한컴오피스)이 설치되어 있지 않거나 COM 연결에 실패했습니다.\n"
            "한컴오피스 한글을 설치한 뒤 다시 시도하세요."
        ) from exc


def _create_hwp(visible: bool = False):
    import pythoncom
    import win32com.client as win32

    pythoncom.CoInitialize()
    # Prefer dynamic dispatch to avoid stale gen_py cache issues across Hangul versions.
    hwp = win32.dynamic.Dispatch("HWPFrame.HwpObject")
    try:
        hwp.RegisterModule("FilePathCheckDLL", "FilePathCheckerModuleExample")
    except Exception:
        try:
            hwp.RegisterModule("FilePathCheckDLL", "FilePathCheckerModule")
        except Exception:
            pass
    try:
        hwp.SetMessageBoxMode(0x00090001)
    except Exception:
        pass
    try:
        hwp.XHwpWindows.Item(0).Visible = bool(visible)
    except Exception:
        try:
            hwp.XHwpWindows.Active_XHwpWindow.Visible = bool(visible)
        except Exception:
            pass
    return hwp


def _release_hwp(hwp) -> None:
    import pythoncom

    if hwp is None:
        return
    try:
        hwp.Clear(1)
    except Exception:
        pass
    try:
        hwp.Quit()
    except Exception:
        pass
    try:
        del hwp
    except Exception:
        pass
    try:
        pythoncom.CoUninitialize()
    except Exception:
        pass


def _open_document(hwp, path: Path) -> None:
    # Empty format lets Hangul auto-detect HWP / HWPX / HWPML.
    ok = hwp.Open(
        str(path),
        "",
        "lock:false;forceopen:true;versionwarning:false;suspendpassword:true",
    )
    if ok is False:
        raise RuntimeError(f"문서를 열 수 없습니다: {path.name}")


def _save_as_pdf(hwp, pdf_path: Path) -> None:
    pdf_path = pdf_path.resolve()
    if pdf_path.exists():
        pdf_path.unlink()
    pdf_path.parent.mkdir(parents=True, exist_ok=True)

    # Method 1: SaveAs (best layout fidelity)
    try:
        ok = hwp.SaveAs(str(pdf_path), "PDF", "")
        if ok is not False and pdf_path.exists() and pdf_path.stat().st_size > 0:
            return
    except Exception:
        pass

    # Method 2: FileSaveAsPdf action
    try:
        hwp.HAction.GetDefault("FileSaveAsPdf", hwp.HParameterSet.HFileOpenSave.HSet)
        hwp.HParameterSet.HFileOpenSave.filename = str(pdf_path)
        hwp.HParameterSet.HFileOpenSave.Format = "PDF"
        hwp.HAction.Execute("FileSaveAsPdf", hwp.HParameterSet.HFileOpenSave.HSet)
        if pdf_path.exists() and pdf_path.stat().st_size > 0:
            return
    except Exception:
        pass

    # Method 3: XHwpPrint.RunToPDF (Microsoft Print to PDF / Hancom PDF)
    printers = ["Hancom PDF", "Microsoft Print to PDF"]
    last_err: Optional[Exception] = None
    for printer in printers:
        try:
            doc = hwp.XHwpDocuments.Item(0)
            printer_obj = doc.XHwpPrint
            printer_obj.filename = str(pdf_path)
            printer_obj.PrinterName = printer
            printer_obj.PrintMethod = 0
            printer_obj.RunToPDF()
            # Print jobs can lag slightly
            for _ in range(50):
                if pdf_path.exists() and pdf_path.stat().st_size > 0:
                    return
                time.sleep(0.1)
        except Exception as exc:
            last_err = exc
            continue

    raise RuntimeError(
        "PDF 저장에 실패했습니다. 한글 PDF 저장 기능 또는 "
        f"'Microsoft Print to PDF' 프린터를 확인하세요. ({last_err})"
    )


def _extract_pages(src_pdf: Path, dst_pdf: Path, pages_1based: list[int]) -> int:
    doc = fitz.open(src_pdf)
    try:
        if len(pages_1based) == doc.page_count and pages_1based == list(
            range(1, doc.page_count + 1)
        ):
            if src_pdf.resolve() != dst_pdf.resolve():
                shutil.copy2(src_pdf, dst_pdf)
            return doc.page_count

        out = fitz.open()
        try:
            for p in pages_1based:
                out.insert_pdf(doc, from_page=p - 1, to_page=p - 1)
            out.save(dst_pdf, garbage=4, deflate=True)
            return out.page_count
        finally:
            out.close()
    finally:
        doc.close()


def _apply_quality(pdf_path: Path, quality: Quality) -> None:
    if quality is Quality.VERY_HIGH:
        return

    dpi = quality.image_dpi or 150
    jpeg_q = quality.jpeg_quality or 75
    tmp = pdf_path.with_suffix(".tmp.pdf")
    src = fitz.open(pdf_path)
    try:
        out = fitz.open()
        try:
            zoom = dpi / 72.0
            matrix = fitz.Matrix(zoom, zoom)
            for page in src:
                pix = page.get_pixmap(matrix=matrix, alpha=False)
                img_page = out.new_page(width=page.rect.width, height=page.rect.height)
                try:
                    img_bytes = pix.tobytes("jpeg", jpg_quality=jpeg_q)
                except TypeError:
                    img_bytes = pix.tobytes("jpeg")
                img_page.insert_image(page.rect, stream=img_bytes)
            out.save(tmp, garbage=4, deflate=True)
        finally:
            out.close()
    finally:
        src.close()

    if tmp.exists():
        tmp.replace(pdf_path)


def get_page_count(source: Path, visible: bool = False) -> int:
    source = Path(source).resolve()
    if not source.exists():
        raise FileNotFoundError(str(source))
    hwp = None
    tmp_dir = Path(tempfile.mkdtemp(prefix="hwp2pdf-"))
    try:
        tmp_src = tmp_dir / source.name
        shutil.copy2(source, tmp_src)
        hwp = _create_hwp(visible=visible)
        _open_document(hwp, tmp_src)
        return int(hwp.PageCount)
    finally:
        try:
            if hwp is not None:
                hwp.Clear(1)
        except Exception:
            pass
        _release_hwp(hwp)
        shutil.rmtree(tmp_dir, ignore_errors=True)


class HangulSession:
    """Reuse one Hangul COM instance across many conversions."""

    def __init__(self, visible: bool = False):
        self.visible = visible
        self.hwp = None

    def __enter__(self):
        self.hwp = _create_hwp(visible=self.visible)
        return self

    def __exit__(self, exc_type, exc, tb):
        _release_hwp(self.hwp)
        self.hwp = None
        return False


def convert_file(
    source: Path,
    output: Path,
    options: ConvertOptions,
    progress: Optional[ProgressCallback] = None,
    hwp=None,
) -> ConvertResult:
    """Convert one file. Pass a shared `hwp` COM object to speed up batch jobs."""
    source = Path(source).resolve()
    output = Path(output).resolve()
    started = time.perf_counter()
    result = ConvertResult(source=source)
    owns_hwp = hwp is None

    def report(msg: str, frac: float) -> None:
        if progress:
            progress(msg, max(0.0, min(1.0, frac)))

    try:
        if not source.exists():
            raise FileNotFoundError(f"파일이 없습니다: {source}")
        if not is_supported(source):
            raise ValueError(f"지원하지 않는 형식입니다: {source.suffix}")

        if output.exists() and not options.overwrite:
            result.skipped = True
            result.error = "이미 존재하는 파일 (덮어쓰기 꺼짐)"
            return result

        report("한글 준비 중…", 0.05)
        tmp_dir = Path(tempfile.mkdtemp(prefix="hwp2pdf-"))
        try:
            tmp_src = tmp_dir / source.name
            tmp_pdf = tmp_dir / "converted.pdf"
            shutil.copy2(source, tmp_src)

            if hwp is None:
                hwp = _create_hwp(visible=options.visible_hangul)
            report("문서 여는 중…", 0.15)
            _open_document(hwp, tmp_src)

            page_count = int(hwp.PageCount)
            result.page_count = page_count
            pages = parse_page_range(options.page_range, page_count)

            report(f"PDF 변환 중… ({page_count}쪽)", 0.35)
            _save_as_pdf(hwp, tmp_pdf)

            try:
                hwp.Clear(1)
            except Exception:
                pass

            report("페이지 정리 중…", 0.7)
            output.parent.mkdir(parents=True, exist_ok=True)
            staged = tmp_dir / "final.pdf"
            exported = _extract_pages(tmp_pdf, staged, pages)
            result.pages_exported = exported

            if options.quality is not Quality.VERY_HIGH:
                report("품질 적용 중…", 0.85)
                _apply_quality(staged, options.quality)

            if output.exists():
                output.unlink()
            shutil.move(str(staged), str(output))
            result.output = output
            report("완료", 1.0)
        finally:
            if owns_hwp:
                _release_hwp(hwp)
            shutil.rmtree(tmp_dir, ignore_errors=True)
    except Exception as exc:
        result.error = str(exc)
        report(f"실패: {exc}", 1.0)

    result.elapsed_sec = time.perf_counter() - started
    return result


def convert_batch(
    sources: list[Path],
    output_dir: Path,
    options: ConvertOptions,
    progress: Optional[Callable[[int, int, str, float], None]] = None,
) -> BatchSummary:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    summary = BatchSummary()
    total = len(sources)
    with HangulSession(visible=options.visible_hangul) as session:
        for idx, source in enumerate(sources, start=1):
            out = default_output_path(Path(source), output_dir)

            def file_progress(msg: str, frac: float, i=idx, src=source) -> None:
                if progress:
                    progress(i, total, f"[{i}/{total}] {Path(src).name} — {msg}", frac)

            result = convert_file(
                Path(source),
                out,
                options,
                progress=file_progress,
                hwp=session.hwp,
            )
            summary.results.append(result)

    return summary


def probe_environment() -> dict:
    info = {
        "hangul_ok": False,
        "hangul_error": "",
        "pymupdf": getattr(fitz, "VersionBind", "?"),
    }
    try:
        _ensure_hangul_available()
        info["hangul_ok"] = True
    except Exception as exc:
        info["hangul_error"] = str(exc)
    return info
