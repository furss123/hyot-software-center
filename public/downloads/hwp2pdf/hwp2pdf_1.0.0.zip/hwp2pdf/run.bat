@echo off
setlocal
cd /d "%~dp0"

set "PY=%LocalAppData%\Programs\Python\Python312\python.exe"
set "PYW=%LocalAppData%\Programs\Python\Python312\pythonw.exe"
if not exist "%PY%" set "PY=python"
if not exist "%PYW%" set "PYW=pythonw"

"%PY%" -c "import customtkinter, pymupdf, win32com.client" 1>nul 2>nul
if errorlevel 1 (
  "%PY%" -m pip install -r requirements.txt 1>nul 2>nul
)

start "" "%PYW%" "%~dp0app.py"
endlocal
