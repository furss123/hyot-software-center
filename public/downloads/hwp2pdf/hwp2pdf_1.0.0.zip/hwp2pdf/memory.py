"""Remembers the user's last choices and how much they converted today."""

from __future__ import annotations

import json
import os
from datetime import date, datetime
from pathlib import Path

_FILE = Path(os.environ.get("APPDATA", Path.home())) / "hwp2pdf" / "settings.json"


def load() -> dict:
    try:
        return json.loads(_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save(data: dict) -> None:
    try:
        _FILE.parent.mkdir(parents=True, exist_ok=True)
        _FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def add_today(data: dict, count: int) -> int:
    """Add to today's tally and return the new total."""
    today = date.today().isoformat()
    if data.get("today") != today:
        data["today"], data["today_count"] = today, 0
    data["today_count"] = int(data.get("today_count", 0)) + count
    return data["today_count"]


def today_count(data: dict) -> int:
    return int(data.get("today_count", 0)) if data.get("today") == date.today().isoformat() else 0


def greeting(now: datetime | None = None) -> str:
    h = (now or datetime.now()).hour
    if 5 <= h < 11:
        return "좋은 아침이에요. 오늘도 가볍게 시작해요"
    if 11 <= h < 14:
        return "점심은 챙겨 드셨어요?"
    if 14 <= h < 18:
        return "오후도 조금만 더 힘내요"
    if 18 <= h < 22:
        return "오늘 하루도 수고 많으셨어요"
    return "늦은 시간까지 고생 많으세요"
